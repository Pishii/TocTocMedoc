<?php
    $pageName = "Recherche de remédes";
    require("../php/db_connection.php");
    require_once("../php/config_global.php");
?>
<!DOCTYPE html>
<html>
        <?php
            displayHead($cssPath, $charset, $appname, $pageName);
        ?>
    <body>

    </body>
</html>