

<?php
    $appname = "Toc Toc Medoc";
    $charset = "utf-8";
    $cssPath = array(0 => "css/main.css");
    $lang = "fr";

    function displayHead(
    array $cssPath, string $charset,
    string $appName, string $pageName)
    {
        echo "<head>";

        foreach ($cssPath as $key => $value) {
            echo "\t\t<link rel=\"stylesheet\" href=\"$value\" />";
        }

        echo "<meta charset = \"$charset\" />";
        echo "<title>$pageName - $appname</title>";
    }

    echo "</head>"
?>


