$(document).ready(function(){
    
    // Nav slide toggle
    $("i.icon").click(function(){ 
        $(".nav-list").slideToggle()
    });
    
    //Sticky NavBar
   /* $(window).scroll(function(){
        var sc = $(this).scrollTop();
        if (sc > 50){
            $("header").addClass("sticky");
        }else{
            $("header").removeClass("sticky");
        }
        
    })*/
});
                  

/*


*/
   

                  