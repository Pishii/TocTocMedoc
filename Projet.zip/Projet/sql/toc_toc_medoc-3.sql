-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 29 avr. 2020 à 21:09
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `toc_toc_medoc-3`
--

-- --------------------------------------------------------

--
-- Structure de la table `chatbot`
--

DROP TABLE IF EXISTS `chatbot`;
CREATE TABLE IF NOT EXISTS `chatbot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `user` longtext NOT NULL,
  `chatbot` longtext NOT NULL,
  `action` varchar(255) NOT NULL,
  `del_msg` tinyint(4) NOT NULL DEFAULT 1,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_,user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `chatbot`
--

INSERT INTO `chatbot` (`id`, `id_user`, `user`, `chatbot`, `action`, `del_msg`, `date`) VALUES
(78, 20, 'hi', 'hello', 'text', 0, '2020-04-29 15:58:35'),
(79, 20, 'how are you', 'I am fine, thank you ', 'text', 0, '2020-04-29 15:59:36'),
(80, 20, 'hi', 'hello', 'text', 1, '2020-04-29 19:57:12'),
(81, 20, 'quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query', 1, '2020-04-29 19:57:44'),
(82, 20, 's.dkjskj', ' Je suis désolé mais je ne sais pas exactement comment vous aider', 'text', 1, '2020-04-29 20:00:46');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

DROP TABLE IF EXISTS `membres`;
CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `motdepasse` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `mail`, `motdepasse`) VALUES
(19, 'melin', 'melin@gmail.com', '209d5fae8b2ba427d30650dd0250942af944a0c9'),
(20, 'toto', 'toto@gmail.com', '209d5fae8b2ba427d30650dd0250942af944a0c9'),
(21, 'deter', 'deter@gmail.com', '027bf5f695cd0cdf548f2316b2d20c6b1b855c2f'),
(25, 'Jean Admin', 'jean@mail.fr', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Structure de la table `mesrndvs`
--

DROP TABLE IF EXISTS `mesrndvs`;
CREATE TABLE IF NOT EXISTS `mesrndvs` (
  `id_rdv` int(11) NOT NULL AUTO_INCREMENT,
  `id_m` int(11) NOT NULL,
  `date` date NOT NULL,
  `heure` time(6) NOT NULL,
  `medecin` varchar(100) NOT NULL,
  `specialite` varchar(50) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  PRIMARY KEY (`id_rdv`),
  KEY `id_m` (`id_m`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `mesrndvs`
--

INSERT INTO `mesrndvs` (`id_rdv`, `id_m`, `date`, `heure`, `medecin`, `specialite`, `adresse`) VALUES
(21, 19, '2020-04-30', '17:00:00.000000', 'David', 'Ophtalmo', 'Drancy'),
(24, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(25, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(26, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(27, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(28, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(29, 20, '2020-04-28', '13:13:00.000000', 'test', 'test', 'test'),
(30, 20, '2020-04-29', '12:12:00.000000', 'TEST2', 'TEST2', 'TEST2'),
(31, 20, '2020-04-29', '14:16:00.000000', 'TEST5', 'TEST5', 'TEST5'),
(32, 20, '2020-04-30', '16:16:00.000000', 'MEDECIN', 'SPECIALITE', 'ADRESSE'),
(33, 19, '2020-04-30', '12:12:00.000000', 'TEST', 'TEST', 'TEST'),
(34, 20, '2020-04-30', '12:12:00.000000', 'CHICHE', 'KJDQZEGF3EERGE', 'EFQERG');

-- --------------------------------------------------------

--
-- Structure de la table `mes_traitement`
--

DROP TABLE IF EXISTS `mes_traitement`;
CREATE TABLE IF NOT EXISTS `mes_traitement` (
  `id_medoc` int(11) NOT NULL AUTO_INCREMENT,
  `idt` int(11) NOT NULL,
  `type_prise` varchar(255) NOT NULL,
  `matin` int(11) NOT NULL,
  `midi` int(11) NOT NULL,
  `soir` int(11) NOT NULL,
  `nom_medoc` varchar(255) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `lundi` int(11) NOT NULL,
  `mardi` int(11) NOT NULL,
  `mercredi` int(11) NOT NULL,
  `jeudi` int(11) NOT NULL,
  `vendredi` int(11) NOT NULL,
  `samedi` int(11) NOT NULL,
  `dimanche` int(11) NOT NULL,
  PRIMARY KEY (`id_medoc`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `mes_traitement`
--

INSERT INTO `mes_traitement` (`id_medoc`, `idt`, `type_prise`, `matin`, `midi`, `soir`, `nom_medoc`, `date_debut`, `date_fin`, `lundi`, `mardi`, `mercredi`, `jeudi`, `vendredi`, `samedi`, `dimanche`) VALUES
(1, 19, 'Comprimé', 2, 3, 2, 'doliprane', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(2, 19, 'Cuillère à soupe', 2, 3, 2, 'doliprane', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(3, 19, 'Cuillère à soupe', 2, 3, 2, 'doliprane', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(4, 19, 'Cuillère à soupe', 2, 3, 2, 'doliprane', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(5, 19, 'Comprimé', 1, 1, 1, 'doli', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(6, 19, 'Comprimé', 1, 1, 1, 'doli', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(7, 19, 'Comprimé', 1, 1, 1, 'doli', '2020-04-24', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(16, 20, 'Comprimé', 4, 4, 4, 'TEST', '2020-04-29', '2020-04-30', 0, 0, 0, 0, 0, 0, 0),
(9, 21, 'Cuillère à café', 1, 2, 3, 'dedede', '2020-04-28', '2020-01-31', 0, 0, 0, 0, 0, 0, 0),
(10, 21, 'Cuillère à café', 1, 2, 3, 'okoko', '2020-04-21', '2020-04-29', 0, 0, 0, 0, 0, 0, 0),
(15, 20, 'Cuillère à café', 3, 6, 9, 'TEST', '2020-04-29', '2020-04-30', 0, 0, 0, 0, 0, 0, 0),
(17, 20, 'Comprimé', 4, 4, 4, 'merde', '2020-04-29', '2020-05-27', 0, 0, 0, 0, 0, 0, 0),
(18, 20, 'Cuillère à café', 3, 3, 3, 'TEST8', '2020-04-30', '2020-05-01', 1, 1, 1, 0, 0, 0, 0),
(19, 20, 'Comprimé', 6, 0, 7, 'MEDOC', '2020-04-30', '2020-05-01', 1, 1, 0, 0, 0, 0, 0),
(20, 20, 'Comprimé', 3, 0, 5, 'TOTO', '2020-04-30', '2020-05-02', 1, 1, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id_Q` int(11) NOT NULL AUTO_INCREMENT,
  `question` longtext NOT NULL,
  `réponse` longtext NOT NULL,
  `action` varchar(255) NOT NULL,
  PRIMARY KEY (`id_Q`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`id_Q`, `question`, `réponse`, `action`) VALUES
(1, 'hi', 'hello', 'text'),
(2, 'how are you ?', 'I am fine, thank you ', 'text'),
(3, 'Quelle heure est-il ', 'echo $child2;', 'query'),
(4, 'Quelle est la date d\'aujourd\'hui ', 'echo $child1;', 'query'),
(5, 'peux tu m\'aider à prendre un rendez-vous médical', 'Avec plaisir ! <a href=\"https://www.doctolib.com\" target=\"_blank\">Cliquez ici :)</a>', 'text'),
(6, 'peux tu m\'aider à trouver un itinéraire pour mon rendez-vous', 'Tes désirs sont des ordres !<a href=\"https://www.google.com/maps\" target=\"_blank\"> clique ici :)</a>', 'text'),
(7, 'Quel est le nom de mon médicament', 'echo $nom_medoc;', 'query'),
(8, 'quand est ce que mon traitement se termine', 'echo $date_fin;', 'query'),
(13, 'Quel est mon prochain rendez-vous médical', 'echo \"Ton prochain rendez-vous est prévu pour le \".$date_rdv.\" à \".$heure_rdv.\" avec le docteur \".$nom_med;', 'query');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `mesrndvs`
--
ALTER TABLE `mesrndvs`
  ADD CONSTRAINT `mesrndvs_ibfk_1` FOREIGN KEY (`id_m`) REFERENCES `membres` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
