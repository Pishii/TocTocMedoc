<?php
session_start();
$bdd= mysqli_connect("127.0.0.1", "root", "", "test");
?>
<html lang="fr">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Modification des tables</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

      <!-- Main CSS-->
      <link href="css/theme.css" rel="stylesheet" media="all">
   </head>
   <body class="animsition">
      <div class="page-wrapper">
         <!-- HEADER MOBILE-->
         <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
               <div class="container-fluid">
                  <div class="header-mobile-inner">
                     <a class="logo"  href="Admin2.php">
                     <img src="images/icon/logo.png" alt="TocTocMedoc" />
                     </a>
                     <button class="hamburger hamburger--slider" type="button">
                     <span class="hamburger-box">
                     <span class="hamburger-inner"></span>
                     </span>
                     </button>
                  </div>
               </div>
            </div>
            <nav class="navbar-mobile">
               <div class="container-fluid">
                  <ul class="navbar-mobile__list list-unstyled">
                     <li>
                        <a href="table.html">
                        <i class="fas fa-table"></i>Tables</a>
                     </li>
                  </ul>
               </div>
            </nav>
         </header>
         <!-- END HEADER MOBILE-->
         <!-- MENU SIDEBAR-->
         <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
               <a href="Admin2.php">
                     <img src="images/icon/logo.png" alt="TocTocMedoc" />
               </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
               <nav class="navbar-sidebar">
                  <ul class="list-unstyled navbar__list">
                     <li class="has-sub">
                        <a class="js-arrow" href="#">
                        <i class="fas fa-table"></i>Tables</a>
                        <form action="modif_tables.php" method="POST">
                           <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                              <div class="modal-body">
                                 <button type="submit" name="symptome" class="btn btn-primary">Symptômes</button>
                                 <button type="submit" name="remede" class="btn btn-primary">Remèdes</button>
                                 <button type="submit" name="syndrome" class="btn btn-primary">Syndromes</button>
                                 <button type="submit" name="soigne" class="btn btn-primary">Soigne</button>
                                 <button type="submit" name="fpd" class="btn btn-primary">Fait_partie_de</button>
                              </div>
                           </ul>
                        </form>
                     </li>
                  </ul>
               </nav>
            </div>
         </aside>
         <!-- END MENU SIDEBAR-->
         <!-- PAGE CONTAINER-->
         <div class="page-container">
             <!-- HEADER DESKTOP-->
            <header class="header-desktop">
               <div class="section__content section__content--p30">
                  <div class="container-fluid">
                     <div class="header-wrap">
                        <div class="header-button">
                           <div class="account-wrap">
                              <div class="account-item clearfix js-item-menu">
                                 <div class="image">
                                    <img src="images/icon/Avatar_Penguin.png" alt="John Doe" />
                                 </div>
                                 <div class="content">
                                    <a class="js-acc-btn" href="#">ADMIN</a>
                                 </div>
                                 <div class="account-dropdown js-dropdown">
                                    <div class="info clearfix">
                                       <div class="image">
                                          <a href="#">
                                          <img src="images/icon/Avatar_Penguin.png" alt="John Doe" />
                                          </a>
                                       </div>
                                       <div class="content">
                                          <h5 class="name">
                                             <a href="#"><?php echo $_SESSION['auth'];?> </a>
                                          </h5>
                                          <span class="email"><?php echo $_SESSION['mail'];?></span>
                                       </div>
                                    </div>
                                    <div class="account-dropdown__footer">
                                       <a href="../Deconnexion.php">
                                       <i class="zmdi zmdi-power"></i>Déconnecter</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </header>
            <!-- HEADER DESKTOP-->
<?php			 
if(isset($_POST['symptome_edit_btn']))
{
	$edit_id=$_POST['edit_id'];
	$query= "SELECT * FROM SYMPTOMES WHERE id_symptome = '$edit_id'";
	$query_run= mysqli_query($bdd,$query);
	foreach($query_run as $row)
	{
?>

<div class="container-fluid">

<!-- DataTales Example -->
<div class="main-content">
<div class="section__content section__content--p30">

    <div class="card-body">

		<form action="code_admin.php" method="POST">

        <div class="modal-body">
			<h3 class="title-5 m-b-35">Modifier un Symptôme</h3>
            <div class="form-group">
                <label> Nom Commun </label>
                <input type="text" name="nom_commun" class="form-control" value="<?php echo utf8_encode($row['nom_commun'])?>">
            </div>
            <div class="form-group">
                <label> Description </label>
                <input type="text" name="description_symptome" class="form-control" value="<?php echo utf8_encode($row['description_symptome'])?>">
            </div>
        </div>
        <div class="modal-footer">
			<input type="hidden" name="update_id" value="<?php echo $edit_id; ?>">
            <button type="submit" name="symptome_update_btn" class="btn btn-danger"> Editer</button>
			<a href="modif_symptomes.php" class="btn btn-danger"> Annuler </a>
			
        </div>
      </form>
	  
    </div>
</div>
</div>

<?php
}
}
if(isset($_POST['remede_edit_btn']))
{
	$edit_id=$_POST['edit_id'];
	$query= "SELECT * FROM REMEDES WHERE id_remede = '$edit_id'";
	$query_run= mysqli_query($bdd,$query);
	foreach($query_run as $row)
	{
?>

<div class="container-fluid">

<!-- DataTales Example -->
<div class="main-content">
<div class="section__content section__content--p30">

    <div class="card-body">

		<form action="code_admin.php" method="POST">

        <div class="modal-body">
			<h3 class="title-5 m-b-35">Modifier un Remède</h3>
            <div class="form-group">
                <label> Nom Commun </label>
                <input type="text" name="nom_commun" class="form-control" value="<?php echo utf8_encode($row['nom_remede'])?>">
            </div>
            <div class="form-group">
                <label> Description </label>
                <input type="text" name="description_remede" class="form-control" value="<?php echo utf8_encode($row['description_remede'])?>">
            </div>
			<div class="form-group">
                <label> Classe </label>
                <input type="text" name="classe_remede" class="form-control" value="<?php echo utf8_encode($row['classe_remede'])?>">
            </div>
        </div>
        <div class="modal-footer">
			<input type="hidden" name="update_id" value="<?php echo $edit_id; ?>">
            <button type="submit" name="remede_update_btn" class="btn btn-danger"> Editer</button>
			<a href="modif_remedes.php" class="btn btn-danger"> Annuler </a>
			
        </div>
      </form>
	  
    </div>
</div>
</div>

<?php
}
}
if(isset($_POST['syndrome_edit_btn']))
{
	$edit_id=$_POST['edit_id'];
	$query= "SELECT * FROM SYNDROMES WHERE id_syndrome = '$edit_id'";
	$query_run= mysqli_query($bdd,$query);
	foreach($query_run as $row)
	{
?>

<div class="container-fluid">

<!-- DataTales Example -->
<div class="main-content">
<div class="section__content section__content--p30">

    <div class="card-body">

		<form action="code_admin.php" method="POST">

        <div class="modal-body">
			<h3 class="title-5 m-b-35">Modifier un Syndrome</h3>
            <div class="form-group">
                <label> Nom Commun </label>
                <input type="text" name="nom_commun" class="form-control" value="<?php echo utf8_encode($row['nom_syndrome'])?>">
            </div>
            <div class="form-group">
                <label> Description </label>
                <input type="text" name="description_syndrome" class="form-control" value="<?php echo utf8_encode($row['description_syndrome'])?>">
            </div>
			<div class="form-group">
                <label> Classification </label>
                <input type="text" name="classe" class="form-control" value="<?php echo utf8_encode($row['classification'])?>">
            </div>
        </div>
        <div class="modal-footer">
			<input type="hidden" name="update_id" value="<?php echo $edit_id; ?>">
            <button type="submit" name="syndrome_update_btn" class="btn btn-danger"> Editer</button>
			<a href="modif_syndromes.php" class="btn btn-danger"> Annuler </a>
			
        </div>
      </form>
	  
    </div>
</div>
</div>

<?php
}
}
if(isset($_POST['soigne_edit_btn']))
{
	$edit_id1=$_POST['edit_id1'];
	$edit_id2=$_POST['edit_id2'];
	$query= "SELECT * FROM SOIGNE WHERE id_remede = '$edit_id1' AND id_symptome = '$edit_id2'";
	$query_run= mysqli_query($bdd,$query);
	foreach($query_run as $row)
	{
?>
<div class="container-fluid">

<!-- DataTales Example -->
<div class="main-content">
<div class="section__content section__content--p30">

    <div class="card-body">

		<form action="code_admin.php" method="POST">

        <div class="modal-body">
			<h3 class="title-5 m-b-35">Modifier une liaison Remède-Symptôme</h3>
            <div class="form-group">
                <label> ID remede </label>
                <input  type="text"  name="remedeS" class="form-control" value="<?php echo $row['id_remede']?>">
            </div>
            <div class="form-group">
                <label> ID symptome </label>
                <input  type="text"  name="symptomeS" class="form-control" value="<?php echo $row['id_symptome']?>">
            </div>
			<div class="form-group">
                <label> Posologie </label>
                <input type="text" name="posologie" class="form-control" value="<?php echo utf8_encode($row['posologie'])?>">
            </div>  
        </div>
        <div class="modal-footer">
			<input type="hidden" name="update_id1" value="<?php echo $edit_id1; ?>">
			<input type="hidden" name="update_id2" value="<?php echo $edit_id2; ?>">
            <button type="submit" name="soigne_update_btn" class="btn btn-danger"> Editer</button>
			<a href="modif_soigne.php" class="btn btn-danger"> CANCEL </a>
        </div>
      </form>
	   </div>
    </div>
</div>
<?php
}
}
if(isset($_POST['fpd_edit_btn']))
{
	$edit_id1=$_POST['edit_id1'];
	$edit_id2=$_POST['edit_id2'];
	$query= "SELECT * FROM fait_partie_de WHERE id_syndrome = '$edit_id1' AND id_symptome = '$edit_id2'";
	$query_run= mysqli_query($bdd,$query);
	foreach($query_run as $row)
	{
	?>
	
	<div class="container-fluid">

<!-- DataTales Example -->
<div class="main-content">
<div class="section__content section__content--p30">

    <div class="card-body">
			<h3 class="title-5 m-b-35">Modifier une liaison Syndrome-Symptôme</h3>
		<form action="code_admin.php" method="POST">

        <div class="modal-body">
			<div class="form-group">
                <label> ID syndrome </label>
                <input type="text" name="syndromeF" class="form-control" value="<?php echo $row['id_syndrome']?>">
            </div>
            <div class="form-group">
                <label> ID symptome </label>
                <input type="text" name="symptomeF" class="form-control" value="<?php echo $row['id_symptome']?>">
            </div>        
        </div>
        <div class="modal-footer">
			<input type="hidden" name="update_id1" value="<?php echo $edit_id1; ?>">
			<input type="hidden" name="update_id2" value="<?php echo $edit_id2; ?>">
            <button type="submit" name="fpd_update_btn" class="btn btn-danger"> Editer</button>
			<a href="modif_fait.php" class="btn btn-danger"> Annuler </a>
        </div>
      </form>
	  
    </div>
</div>
<?php
}}?>
 <!-- Jquery JS-->
      <script src="vendor/jquery-3.2.1.min.js"></script>
      <!-- Bootstrap JS-->
      <script src="vendor/bootstrap-4.1/popper.min.js"></script>
      <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
      <!-- Vendor JS       -->
      <script src="vendor/slick/slick.min.js"></script>
      <script src="vendor/wow/wow.min.js"></script>
      <script src="vendor/animsition/animsition.min.js"></script>
      <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
      <script src="vendor/counter-up/jquery.counterup.min.js"></script>
      <script src="vendor/circle-progress/circle-progress.min.js"></script>
      <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
      <script src="vendor/chartjs/Chart.bundle.min.js"></script>
      <script src="vendor/select2/select2.min.js"></script>
      <!-- Main JS-->
      <script src="js/main.js"></script>
	     </body>
</html>