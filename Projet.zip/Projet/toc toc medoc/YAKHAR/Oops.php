<!DOCTYPE html>
<html lang = "fr">
<head>

</head>
    <script>


        function backToSearch(){
            document.location.href="main_menu.php";
        }


    </script>
    <style>

img{
    position: absolute;
    left: 30%;
    top: 6%;
}
    h1{
    position: absolute;
    left: 20%;
    top: 60%;
    }
    button{
position: absolute;
top: 700px;
right: 670px;
height:50px;
 font-size:17px;
  background-color:#00001a; 
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
  border-radius: 8px;
}
button:hover{
  border-radius: 8px;
  background-color: white; 
  color: #00001a; 
  border: 3px solid #00001a;
  font-size:17px;

}
    </style>
<body>

<h1 >
<b>Oops !</b> aucun résultat trouvé, essayez de rechercher à nouveau
</h1>













<button class="btn_back" onclick="backToSearch()">Retourner</button>

</body>
</html>