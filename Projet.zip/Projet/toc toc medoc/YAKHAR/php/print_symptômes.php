<?php
    abstract class Display{
        protected $output;
        protected $blockName;

        public function display(){
            echo "<$blockName>";
            echo $output;
            echo "</$blockName>";
        }

        public abstract function append(string $string);
        public abstract function resetOutput();

        public function setBlockName(string $value){
            $blockName = $value;
        }

        public function getBlockName(){
            return $blockName;
        }
    }

    abstract class DysplayQuery extends Display{
        protected $stmt;
        public function __construct(PDOStatment $stmt){
            $this->stmt = $stmt;
            $this->stmt->closeCursor();
            $this->stmt->execute();
        }

        public abstract function appendRow(array $row);

        public function closeCursorStmt(){
            $this->stmt->closeCursor();
        }

        public function executeCursorStmt(){
            $this->stmt->execute();
        }

        public function resetStmt(){
            $this->closeCursorStmt();
            $this->executeStmt();

            $this->resetOutput();
            foreach ($stmt as $row){
                $this->appendRow($row);
            }
        }
    }


    class DisplayQueryToSelect extends DisplayQuery
    {

        public function __construct(PDOStatment $stmt)
        {
            parent::__construct($stmt);
            $this->stmt->fetchMode(PDO::FETCH_NUM);
            $blockName = "select";

            foreach ($stmt as $row){
                $this->appendRow($row);
            }
        }

        public function append(string $string){
            $output = $output + "<option value=\"$string\">$string</option>";
        }

        public function appendRow(array $row){
            $output = $output + "<option value=\"$row[0]\">$row[1]</option>";
        }

        public function resetOutput(){
            $output = "";
        }

    }

    class DisplayRemedesToSelect extends DisplayQueryToSelect{
        public function __construct(PDOStatment $stmt){
            parent::__construct($stmt);
        }

        public function appendRow(array $row){
            $output = $output + "<option value=\"$row[0]\">$row[0]</option>";
        }
    }

?>