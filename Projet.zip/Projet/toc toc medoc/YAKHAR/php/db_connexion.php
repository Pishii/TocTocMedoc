<?php
    $dbuser = "root";
    $dbpassword="";
    $dbconnection = "mysql:host=localhost;dbname=test";

    /*$dbo = new PDO($dbconnection, $dbuser, $dbpassword);
    $stmtSelectSymptomes = $dbo->prepare(
            "SELECT nom_commun FROM SYMPTOMES ORDER BY nom_commun ASC;");*/
?>