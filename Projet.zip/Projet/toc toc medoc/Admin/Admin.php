<?php
session_start();

//$bdd = new PDO('mysql:host=127.0.0.1;dbname=toc_toc_medoc-3', 'root', '');

$emailpseudo=$_SESSION['mail']; 
include_once '../ConnexionBD.php'; // l'appel a la connexion avec la base de données
 
		
$pseudoafficher ="SELECT * FROM membres WHERE mail= '$emailpseudo'";
$statement = $bdd->prepare($pseudoafficher);
$statement->execute(array(':pseudo' => $pseudoafficher));
 
if(isset($_Get['supprime']) AND !empty($_GET['supprime'])){
	$supprime = (int) $_GET['supprime'];
	
	$req = $bdd->prepare('DELETE FROM membres WHERE id = ?');
	$req->execute(array($supprime));
}

// pour afficher le nombre de patient
$nombrepatient ="SELECT count(*) as nbpatient FROM membres";
$statementnombre= $bdd->prepare($nombrepatient);
$statementnombre->execute();
$donneesNombrePatient =$statementnombre->fetch();

  if(isset($_POST['AjouterQuestion']))
		   {
			 $id_Q=$_POST['id_Q'];
				$question=$_POST['question'];
					
					   

				   
			 $sqlInsert ="INSERT INTO questions (id_Q, question, réponse) VALUES(:id_Q, :question, :réponse)";
			 $statement = $bdd->prepare($sqlInsert);
	         $statement->execute(array(':id_Q' => $id_Q, ':question' => $question));
			    if($statement->rowCount() == 1)
					 {
						echo '<script>alert("insertion avec succ?")</script>';
				 }
					 else
					 {
						echo '<script>alert("Erreur d insertion")</script>';
					}
							   
		   }



	   
		   
		   
?>
<!DOCTYPE html>

<html>

  	<head>
			<title>Administrateur</title>
			<meta charset="utf8">
			
			<!-- Framwork--> 
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

			
			
			<!-- Polices -->
			<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
			<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
			<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
			<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
			<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
			<!-- CSS -->
			
        	<link rel="stylesheet" href="../CSS/vendors/bootstrap.min.css">
        	<style>
				/* css du menu */
				ul {
				list-style-type: none;
				margin: 0;
				padding: 0;
				overflow: hidden;
				background-color: #333;
				height: 70px;
				}

				li {
				float: left;
				}

				li a {
				display: block;
				color: white;
				text-align: center;
				padding: 14px 16px;
				text-decoration: none;
				}

				li a:hover {
				background-color: #111;
				height:70px;
				text-decoration: none;
				}
				.mb-0{
					text-align:center;
					margin-top:20px;
				}

				/* css de la formulaire */
        </style>
		</head>
		<body>
		<header >
	
				
				<!-- La balise <nav> définit un ensemble de liens de navigation. -->
				 <!-- le menu de la page (navbar) -->
				 <ul>
					
			  <li>
				<a  href="#ProfilAdmin">Profil Admin</a>
			  </li>
			  <li >
				<a  href="#VisualiserPatient">Visualiser les Patients</a>
			  </li>
			  <li>
				<a  href="#VisualiserQuestions">Visualiser les Questions</a>
			  </li>
			  <li>
				<a  href="../Deconnexion.php"> Deconnexion </a>
			  </li>
			</ul>
					
	

		</header> </br>
		<div class="container-fluid p-0">
			<section>
			<div class="container">
			<div class="row">
			  <div class="col-lg-12 text-center">
			 
			   <?php
			 
			  while ($donnees = $statement->fetch())
					{
				echo '<h2 class="section-heading text-uppercase"> Administrateur de toc-toc-medoc  :'.$donnees['pseudo'].'</h2>';
					}
			   ?>
				<!-- <h3 class="section-subheading text-muted">n'h?iter pas ?nous contacter pour tout renseignement.</h3> -->
			  </div>
			</div></br>
			
		   <div class="row">
			<div class="col-sm-6">
				<div class="equipe">
				  <h4>Yao SOGADZI</h4>
				  <p class="text-muted">Enseignant à l'université Paris 13 Villetaneuse</p>
				  <p class="text-muted">Matser 1 Informatique Institut Galilée - Université Paris 13 .</p>
				</div>
			</div>
			 
		   </div>
			
		 
		   </div>
		   <div class="row">
		 
		
								<div class="resume-section p-3 p-lg-5 d-flex flex-column">
									
												<div class="table-detail">
													<!-- <div class="iconbox bg-info"> -->
														<i class="fa fa-users" style="font-size:48px"></i>
													<!-- </div> -->
												</div>

												<div class="table-detail">
												
													<h2 class=""mb-5"">Nombre de Patients :</h2>
													<h4 class="m-t-0 m-b-5"><b><?php echo $donneesNombrePatient['nbpatient']?></b></h4>
												
													
												</div>
											  

								</div>
			</div> 
		</section>
		
		<section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserPatient">
		<h2 class="mb-5">La liste Des Patients </h2>
		
		
		 
		 <div class="fresh-table">
			<table id="fresh-table" class="table">
			<?php
			
			$SqlAficherJoueurs="SELECT * FROM membres";
			$statementAfficherJoueurs= $bdd->prepare($SqlAficherJoueurs);
			$statementAfficherJoueurs->execute();
			
			$afficherpatient ="SELECT * FROM membres";
			$statementafficherpatient= $bdd->prepare($afficherpatient);
			$statementafficherpatient->execute();
			?>
			 
			 
							<thead>
								<th>identifiant</th>
								<th  data-sortable="true">Pseudo</th>
								<th  data-sortable="true">E-mail</th>
							</thead>
							<tbody>
			  <?php
							while($donnees = $statementafficherpatient->fetch())
			 {
			   ?>                 <tr>
									<td><?php echo $donnees['id'] ?></td>
									<td><?php echo $donnees['pseudo'] ?></td>
									<td><?php echo $donnees['mail'] ?></td>
									<td><a href="supprimerPatient.php?mail=<?php echo $donnees['mail'] ?>" onclick="return confirm('voulez-vous supprimer ce patient ? o_O!')" role= "button" id="supprime"><i class="fa fa-times"></i>supprimer</a></td>
									
								</tr>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>
		  
		  <section class="resume-section p-3 p-lg-5 d-flex flex-column" id="VisualiserQuestions">
		  <h2 class="mb-5">La liste Des Questions</h2>
		 

		
		 
		 <div class="fresh-table toolbar-color-orange">
			<table id="fresh-table" class="table">
			<?php
			
			$SqlAficherQuestion="SELECT * FROM questions";
			$statementAfficherQuestion= $bdd->prepare($SqlAficherQuestion);
			$statementAfficherQuestion->execute();
			?>
			 
			 
							<thead>
							  
							  <th  data-sortable="true">Ident_Qst</th>
							  <th  data-sortable="true">Questions</th>
							  
							</thead>
							<tbody>
			  <?php
							while($donnees = $statementAfficherQuestion->fetch())
			 {
			   ?>                 <tr>
									<td><?php echo $donnees['id_Q'] ?></td> 
									<td><?php echo $donnees['question'] ?></td>
									
								 </tr>
			 <?php
			 }
			 ?>               
							</tbody>
					
			</table>
			
		  </div>	
		  </section>
		   

		</div>   
	
    </body>

</html>
