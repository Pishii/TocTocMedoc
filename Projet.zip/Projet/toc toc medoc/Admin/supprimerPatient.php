<?php

	$mail=$_GET['mail'];
	include_once '../ConnexionBD.php';
	 //$bdd = new PDO('mysql:host=127.0.0.1;dbname=toc_toc_medoc-3', 'root', '');

	$adminMail="admin@gmail.com";

	if( $mail == $adminMail){
		confirm("vous ne pouvez pas supprimer l'admin");
	}

	if( $mail != $adminMail){
		$sqldelete="DELETE FROM membres WHERE mail='$mail'";
		$statement=$bdd->prepare($sqldelete);
		$statement->execute();
		
	}
	header('location:Admin.php');
?>